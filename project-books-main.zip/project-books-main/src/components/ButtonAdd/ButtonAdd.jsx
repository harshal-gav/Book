import { Button } from './ButtonAdd.styled.js';

function ButtonAdd() {
  return (
    <Button   type="submit">
      Додати
    </Button>
  );
}

export default ButtonAdd;
