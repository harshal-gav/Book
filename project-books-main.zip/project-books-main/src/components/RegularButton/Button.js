const RegularButton = ({ color, text }) => {
  return <button>{text}</button>;
};

export default RegularButton;
