import { CommonContainer } from './Container.styled';

const Container = ({ children }) => {
  return <CommonContainer>{children}</CommonContainer>;
};

export default Container;
