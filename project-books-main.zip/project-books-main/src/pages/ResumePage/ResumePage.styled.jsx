import styled from '@emotion/styled'

export const Div = styled.div`
  min-height: 100vh;
  background-color: #f6f7fb;
  margin: 0 auto;
`;
